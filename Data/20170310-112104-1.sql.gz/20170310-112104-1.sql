-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : admin
-- 
-- Part : #1
-- Date : 2017-03-10 11:21:04
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `admin_admin`
-- -----------------------------
DROP TABLE IF EXISTS `admin_admin`;
;

-- -----------------------------
-- Records of `admin_admin`
-- -----------------------------
INSERT INTO `admin_admin` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `admin_admin` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `admin_admin` VALUES ('', '', '', '', '', '', '', '', '', '', '');
