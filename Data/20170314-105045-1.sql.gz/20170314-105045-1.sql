-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : bdm257480513.my3w.com
-- Port     : 3306
-- Database : bdm257480513_db
-- 
-- Part : #1
-- Date : 2017-03-14 10:50:45
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `admin_admin`
-- -----------------------------
DROP TABLE IF EXISTS `admin_admin`;
;

-- -----------------------------
-- Records of `admin_admin`
-- -----------------------------
INSERT INTO `admin_admin` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `admin_admin` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `admin_admin` VALUES ('', '', '', '', '', '', '', '', '', '', '');
